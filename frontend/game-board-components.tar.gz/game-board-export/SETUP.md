# Game Board Components — Quick Setup

## What's included

- **ChessBoard/** — 8x8 chess board with Unicode pieces, file/rank labels, move indicators
- **TicTacToeBoard/** — 3x3 grid with X/O marks, winning-cell highlights
- **GameBoardDemo/** — Interactive demo page to preview both boards
- **index.css** — Global styles (Roboto font import)

## How to use in your React project

1. Copy `ChessBoard/` and `TicTacToeBoard/` into your `src/components/` folder.
2. Make sure `index.css` (or your global stylesheet) imports the Roboto font:
   ```css
   @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap');
   body { font-family: 'Roboto', sans-serif; }
   ```
3. Import and use:
   ```jsx
   import ChessBoard from './components/ChessBoard';
   import TicTacToeBoard from './components/TicTacToeBoard';
   ```

## Color palette

All components use this palette:
- `#662691` (purple) — primary
- `#BEB8EB` (lavender) — borders, secondary
- `#F56476` (coral) — errors, danger
- `#ADFCF9` (mint) — success, ready
- `#F8F4A6` (yellow) — warnings, highlights

See each component's README.md for the full props reference.
